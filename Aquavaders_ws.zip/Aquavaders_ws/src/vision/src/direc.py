#!/usr/bin/env python3
import cv2
import numpy as np
import rospy
from std_msgs.msg import String

low_blue = np.array([110, 120, 174])
high_blue = np.array([160, 240, 255])


def empty(a):
    pass


def image_fill(Binary_image):
    # Mask used to flood filling.
    im_th = Binary_image.astype('uint8').copy()
    h, w = im_th.shape[:2]
    im_floodfill = im_th.copy()
    mask = np.zeros((h+2, w+2), np.uint8)

    # Floodfill from point (0, 0)
    cv2.floodFill(im_floodfill, mask, (0, 0), 1)

    # Invert floodfilled image
    im_floodfill_inv = cv2.bitwise_not(im_floodfill)

    # Combine the two images to get the foreground.
    im_out = im_th | im_floodfill_inv
    im_out[im_out == 254] = 0
    return im_out


def detect():
    cam = cv2.VideoCapture(0)
    r_val, img = cam.read()
    cnt = 0
    while r_val:
        if cnt < 20:
            continue
        else:
            cnt = 0
        cnt = cnt + 1
        r_val, img = cam.read()
        imgHSV = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
        imgGrey = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        blue_mask = cv2.inRange(imgHSV, low_blue, high_blue)
        blue_mask = cv2.GaussianBlur(blue_mask, (7, 7), cv2.BORDER_DEFAULT)
        blue_mask = cv2.medianBlur(blue_mask, 5)
        # blue_mask = image_fill(blue_mask)
        imgResult = cv2.bitwise_and(img, img, mask=blue_mask)
        imgCanny = cv2.Canny(blue_mask, 100, 50)
        contours, hierarchy = cv2.findContours(
            blue_mask, cv2.RETR_TREE, cv2.CHAIN_APPROX_NONE)
        mxArea = -1
        mxContour = contours[0]
        for contour in contours:
            # cv2.drawContours(imgGrey, contour, -1, (255, 0, 0), 3)
            rect = cv2.boundingRect(contour)
            if rect[2] < 20 or rect[3] < 20:
                print("Passed")
                continue  # Threshhold width and height
            # x, y, w, h = rect
            # cv2.rectangle(imgResult, (x, y), (x+w, y+h), (0, 255, 0), 2)
            # print((x+w)*(y+h))
            # approx = cv2.approxPolyDP(
            #     contour, 0.01 * cv2.arcLength(contour, True), True)

            peri = cv2.arcLength(contour, 1)
            approx = cv2.approxPolyDP(contour, 0.02*peri, 1)
            x, y, w, h = cv2.boundingRect(approx)
            if len(approx) == 4:
                if int((w)*(h)) > mxArea:
                    mxArea = w*h
                    mxContour = contour
        x, y, w, h = cv2.boundingRect(mxContour)
        cv2.rectangle(imgResult, (x, y), (x+w, y+h), (0, 255, 0), 2)
        direction = 'f'
        leftRatio = w/x
        rightRatio = w/(imgResult.shape[1] - (x + w))
        print(leftRatio, rightRatio)
        if leftRatio < 4.0 and rightRatio < 4.0:
            direction = 'd'
        elif leftRatio > 10.0 and rightRatio > 10.0:
            direction = 'u'
        elif leftRatio < 4.0:
            direction = 'r'
        elif rightRatio < 4.0:
            direction = 'l'

        print("direction")
        print(direction)
        print("type")
        print(type(direction))
        # cv2.imshow("Canny", imgCanny)
        # cv2.imshow("Blue", blue_mask)
        # cv2.imshow("Result", imgResult)
        # cv2.imshow("Grey", imgGrey)
        # cv2.waitKey(0)
        return direction


def trackBars():
    img = cv2.imread("img2.PNG")
    cv2.namedWindow("TrackBars")
    cv2.resizeWindow("TrackBars", 640, 240)
    cv2.createTrackbar("Hue Min", "TrackBars", 0, 179, empty)
    cv2.createTrackbar("Hue Max", "TrackBars", 19, 179, empty)
    cv2.createTrackbar("Sat Min", "TrackBars", 110, 255, empty)
    cv2.createTrackbar("Sat Max", "TrackBars", 240, 255, empty)
    cv2.createTrackbar("Val Min", "TrackBars", 153, 255, empty)
    cv2.createTrackbar("Val Max", "TrackBars", 255, 255, empty)
    while True:
        imgHSV = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
        h_min = cv2.getTrackbarPos("Hue Min", "TrackBars")
        h_max = cv2.getTrackbarPos("Hue Max", "TrackBars")
        s_min = cv2.getTrackbarPos("Sat Min", "TrackBars")
        s_max = cv2.getTrackbarPos("Sat Max", "TrackBars")
        v_min = cv2.getTrackbarPos("Val Min", "TrackBars")
        v_max = cv2.getTrackbarPos("Val Max", "TrackBars")
        print(h_min, h_max, s_min, s_max, v_min, v_max)
        lower = np.array([h_min, s_min, v_min])
        upper = np.array([h_max, s_max, v_max])
        mask = cv2.inRange(imgHSV, lower, upper)
        imgResult = cv2.bitwise_and(img, img, mask=mask)
        cv2.imshow("Result", imgResult)
        cv2.waitKey(1)


def talker(direction):
    print("In talker")
    pub = rospy.Publisher('directions', String, queue_size=10)
    rospy.init_node('openCVpub', anonymous=True)
    rate = rospy.Rate(10)  # 10hz
    while not rospy.is_shutdown():
        rospy.loginfo(direction)
        pub.publish(direction)
        rate.sleep()


ret = detect()

try:
        talker(ret)
except rospy.ROSInterruptException:
        pass


